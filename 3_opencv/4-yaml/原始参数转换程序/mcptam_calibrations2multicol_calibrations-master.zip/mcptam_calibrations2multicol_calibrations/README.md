# mcptam_cali2multicol_cali

mcptam calibrations  files transform to  MultiCol_calibrations

need to run twice 

I'm solving the problem.
